import React, { useState } from "react";

const SUPABASE_URL = "https://wpqbpgesvoofzmlddrie.supabase.co";
const SUPABASE_KEY = "sb_publishable_1sVUjrjossBnjWSUsN-EUg__XE2l2ZI";

export default function App() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    firm: "",
    role: "",
  });

  const [message, setMessage] = useState("");

  const handleSubmit = async () => {
    setMessage("Submitting...");

    const res = await fetch(`${SUPABASE_URL}/rest/v1/leads`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        "Content-Type": "application/json",
        Prefer: "return=representation",
      },
      body: JSON.stringify(form),
    });

    if (res.ok) {
      setMessage("Saved successfully.");
    } else {
      const errorText = await res.text();
      setMessage("Error saving: " + errorText);
      console.error(errorText);
    }
  };

  return (
    <div style={{ padding: 40 }}>
      <h2>LifeArc Intake</h2>

      <input
        placeholder="Name"
        value={form.name}
        onChange={(e) => setForm({ ...form, name: e.target.value })}
      />
      <br />

      <input
        placeholder="Email"
        value={form.email}
        onChange={(e) => setForm({ ...form, email: e.target.value })}
      />
      <br />

      <input
        placeholder="Firm"
        value={form.firm}
        onChange={(e) => setForm({ ...form, firm: e.target.value })}
      />
      <br />

      <input
        placeholder="Role"
        value={form.role}
        onChange={(e) => setForm({ ...form, role: e.target.value })}
      />
      <br />
      <br />

      <button onClick={handleSubmit}>Submit</button>

      <p>{message}</p>
    </div>
  );
}